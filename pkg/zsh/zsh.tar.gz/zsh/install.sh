 ln -s zshrc ~/.zshrc
 
